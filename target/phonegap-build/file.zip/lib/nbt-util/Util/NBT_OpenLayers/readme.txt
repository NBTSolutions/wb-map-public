A collection of NBT built javascript.
code in src/ should be moved to a scripts dir in a project.
test code lives in tests/ and is being built with qunit.

