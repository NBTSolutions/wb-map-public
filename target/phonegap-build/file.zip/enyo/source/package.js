enyo.depends(
	"kernel",
	"ajax",
	"dom",
	"touch",
	"ui"
);
