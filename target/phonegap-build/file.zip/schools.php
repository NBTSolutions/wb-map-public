<?php
	header('Content-Type: application/javascript');
	echo $_GET['callback'].'(';
?>
[{
        "id": "observation.148",
        "properties": {
            "timestamp": "2013-04-19T00:33:16.319Z",
            "id": 148,
            "source_id": 32,
            "version": 0
        },
        "type": "Feature",
        "geometry_name": "location",
        "geometry": {
            "type": "Point",
            "coordinates": [
                -70.161944,
                43.684722
            ]
        }
    },
    {
        "id": "observation.147",
        "properties": {
            "timestamp": "2013-04-19T00:33:16.319Z",
            "id": 147,
            "source_id": 32,
            "version": 0
        },
        "type": "Feature",
        "geometry_name": "location",
        "geometry": {
            "type": "Point",
            "coordinates": [
                -70.109128,
                43.737352
            ]
        }
    },
    {
        "id": "observation.146",
        "properties": {
            "timestamp": "2013-04-19T00:33:16.319Z",
            "id": 146,
            "source_id": 32,
            "version": 0
        },
        "type": "Feature",
        "geometry_name": "location",
        "geometry": {
            "type": "Point",
            "coordinates": [
                -69.117247,
                44.096031
            ]
        }
    },
    {
        "id": "observation.145",
        "properties": {
            "timestamp": "2013-04-19T00:33:16.319Z",
            "id": 145,
            "source_id": 32,
            "version": 0
        },
        "type": "Feature",
        "geometry_name": "location",
        "geometry": {
            "type": "Point",
            "coordinates": [
                -68.365309,
                44.115105
            ]
        }
    },
    {
        "id": "observation.144",
        "properties": {
            "timestamp": "2013-04-19T00:33:16.319Z",
            "id": 144,
            "source_id": 32,
            "version": 0
        },
        "type": "Feature",
        "geometry_name": "location",
        "geometry": {
            "type": "Point",
            "coordinates": [
                -135.330992,
                57.054082
            ]
        }
    },
    {
        "id": "observation.143",
        "properties": {
            "timestamp": "2013-04-19T00:33:16.319Z",
            "id": 143,
            "source_id": 32,
            "version": 0
        },
        "type": "Feature",
        "geometry_name": "location",
        "geometry": {
            "type": "Point",
            "coordinates": [
                -70.102222,
                43.699444
            ]
        }
    }
]
<?php
	echo ")";
?>
